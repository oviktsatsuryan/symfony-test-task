UPGRADE FROM 2.5 to 2.6
=======================

Configuration
-------------
 * The `collate` default table option is deprecated in favor of `collation`

